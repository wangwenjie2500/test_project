#-*-coding:utf-8-*-
import urllib
import urllib2
import time
import json


url = "http://172.10.1.35:8085/api/v0.1/crontrol"
def post(data):
    fullurl = url
    req = urllib2.Request(fullurl,data)
    res = urllib2.urlopen(req)
    rdata = res.read()
    return  rdata

class crontrol(object):
    def __init__(self):
        pass

    def userAuth(self,**kwargs):
        user = kwargs['username']
        try:
            password = kwargs['password']
            data = json.dumps({'type':"userAuth","username":user,"password":password})
            recode = json.loads(post(data=data))
            print({'action': 'login', 'user': '{}'.format(user), 'status': 'ok', 'module': 'userAuth'})
            return recode
        except Exception,msg:
            print(msg)
            print({'action':'login','user':'{}'.format(user),'status':'error','module':'userAuth'})

    def instanceMangnt(self):
        try:
            data = json.dumps({"type":"instanceMangntAll"})
            recode = json.loads(post(data))
            f = []
            for i in recode.keys():
                f.append(recode[i])
            print({'action': 'get instance info', 'user': 'all', 'status': 'ok', 'module': 'instanceMangnt'})
            return f
        except Exception,msg:
            pass