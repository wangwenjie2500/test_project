//post data to server
function serverConnectPost(data){
    var value = data;
    var rcode = " ";
    $.ajax({
        url:"http://172.10.1.35:8085/api/v0.1/crontrol",
        contentType:"application/json;charset=utf-8",
        type:"POST",
        dataType:"json",
        async:false,
        data:JSON.stringify(value),
        success:function (rdata){
            rcode = rdata
        }
    });
    return rcode
}

//domain crontrol function
function instanceCrontrol(UUID,ACTION){
        var domainUUID = UUID;
        var domainAction  = ACTION;
        var domainCrontrolAction = {'type':'instanceCrontrol','data':{'action':domainAction,'UUID':domainUUID}};
        returnCode = serverConnectPost(domainCrontrolAction)
        if (returnCode['code'] == '200'){
            alert(domainAction + "ok")
        } else {
            alert(domainAction + "faild")
        }

    }

